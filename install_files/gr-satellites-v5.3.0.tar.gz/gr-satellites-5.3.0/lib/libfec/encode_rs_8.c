/* Reed-Solomon encoder
 * Copyright 2004, Phil Karn, KA9Q
 * May be used under the terms of the GNU Lesser General Public License (LGPL)
 */
#include <string.h>

#include "fixed.h"

/* Portable C version */
void encode_rs_8(data_t* data, data_t* parity, int pad)
{

#include "encode_rs.h"
}
