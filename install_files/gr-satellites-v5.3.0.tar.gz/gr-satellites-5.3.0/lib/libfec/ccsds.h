typedef unsigned char data_t;
extern unsigned char Taltab[], Tal1tab[];
#define NN 255
#define NROOTS 32
